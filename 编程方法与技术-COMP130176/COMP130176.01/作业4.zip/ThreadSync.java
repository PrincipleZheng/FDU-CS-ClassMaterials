
public class ThreadSync {

    void incA(ThreadA t) {
        ThreadSync.ThreadA.A++;
        EmuExe.execute();
    }

    void decB(ThreadB t) {
        ThreadSync.ThreadB.B--;
        EmuExe.execute();

    }

    volatile int flag = 0;

    class ThreadA implements Runnable {
        Object object;

        public ThreadA(Object object) {
            this.object = object;
        }

        public static volatile int A = 0;

        @Override
        public void run() {

            for (int j = 0; j < 100; j++) {
                //同步代码，大家一起起跑
                synchronized (object) {
                    if (flag == 0) {
                        flag = 1;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 0;
                        object.notify();
                    }
                }
                System.out.println("The value of A is: " + A);
                incA(this);
                //同步代码，等待慢者结束
                synchronized (object) {
                    if (flag == 0) {
                        flag = 1;
                        System.out.println("waiting B");
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 0;
                        object.notify();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of A is: " + A);
                }
            }
        }
    }

    class ThreadB implements Runnable {
        Object object;

        public ThreadB(Object object) {
            this.object = object;
        }

        public static volatile int B = 100;

        @Override
        public void run() {

            for (int j = 0; j < 100; j++) {
                //判断当前是否同步
                if (ThreadA.A + ThreadB.B != 100) {
                    System.out.println("Error!");
                }
                synchronized (object) {
                    if (flag == 0) {
                        flag = 1;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 0;
                        object.notify();
                    }
                }
                System.out.println("The value of B is: " + B);
                decB(this);
                synchronized (object) {
                    if (flag == 0) {
                        flag = 1;
                        System.out.println("waiting A");
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 0;
                        object.notify();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of B is: " + B);
                }

            }

        }
    }

    public static void main(String[] args) {
        Object object = new Object();
        ThreadSync instance = new ThreadSync();
        Thread thread1 = new Thread(instance.new ThreadA(object));
        Thread thread2 = new Thread(instance.new ThreadB(object));
        thread1.start();
        thread2.start();
    }
}
