
public class ThreadSyncTen {

    void incA() {
        ThreadSyncTen.ThreadA.A++;
        EmuExe.execute();
    }
    void incB() {
        ThreadSyncTen.ThreadB.B++;
        EmuExe.execute();
    }
    void incC() {
        ThreadSyncTen.ThreadC.C++;
        EmuExe.execute();
    }
    void incD() {
        ThreadSyncTen.ThreadD.D++;
        EmuExe.execute();
    }
    void incE() {
        ThreadSyncTen.ThreadE.E++;
        EmuExe.execute();
    }

    void decF() {
        ThreadSyncTen.ThreadF.F--;
        EmuExe.execute();
    }
    void decG() {
        ThreadSyncTen.ThreadG.G--;
        EmuExe.execute();
    }
    void decH() {
        ThreadSyncTen.ThreadH.H--;
        EmuExe.execute();
    }
    void decI() {
        ThreadSyncTen.ThreadI.I--;
        EmuExe.execute();
    }
    void decJ() {
        ThreadSyncTen.ThreadJ.J--;
        EmuExe.execute();
    }
    

    volatile int flag = 10;

    class ThreadA implements Runnable {
        Object object;

        public ThreadA(Object object) {
            this.object = object;
        }

        public static volatile int A = 0;

        @Override
        public void run() {

            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of A is: " + A);
                incA();
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        // System.out.println("waiting");
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of A is: " + A);
                }
            }
        }
    }

    class ThreadB implements Runnable {
        Object object;
    
        public ThreadB(Object object) {
            this.object = object;
        }
    
        public static volatile int B = 0;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of B is: " + B);
                incB();
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of B is: " + B);
                }
            }
        }
    }
    
    class ThreadC implements Runnable {

        Object object;
    
        public ThreadC(Object object) {
            this.object = object;
        }
    
        public static volatile int C = 0;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of C is: " + C);
                incC();
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of C is: " + C);
                }
            }
        }
    }
    
    class ThreadD implements Runnable {
        Object object;
    
        public ThreadD(Object object) {
            this.object = object;
        }
    
        public static volatile int D = 0;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of D is: " + D);
                incD();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of D is: " + D);
                }
            }
        }
    }
    
    class ThreadE implements Runnable {
        Object object;
    
        public ThreadE(Object object) {
            this.object = object;
        }
    
        public static volatile int E = 0;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of E is: " + E);
                incE();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of E is: " + E);
                }
            }
        }
    }
    
    class ThreadF implements Runnable {
        Object object;

        public ThreadF(Object object) {
            this.object = object;
        }

        public static volatile int F = 100;

        @Override
        public void run() {

            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of F is: " + F);
                decF();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of F is: " + F);
                }

            }

        }
    }
    
    class ThreadG implements Runnable {
        Object object;
    
        public ThreadG(Object object) {
            this.object = object;
        }
    
        public static volatile int G = 100;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of G is: " + G);
                decG();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of G is: " + G);
                }
    
            }
    
        }
    }
    
    class ThreadH implements Runnable {
        Object object;
    
        public ThreadH(Object object) {
            this.object = object;
        }
    
        public static volatile int H = 100;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of H is: " + H);
                decH();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of H is: " + H);
                }
    
            }
    
        }
    }
    
    class ThreadI implements Runnable {
        Object object;
    
        public ThreadI(Object object) {
            this.object = object;
        }
    
        public static volatile int I = 100;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of I is: " + I);
                decI();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of I is: " + I);
                }
    
            }
    
        }
    }
   
    class ThreadJ implements Runnable {
        Object object;
    
        public ThreadJ(Object object) {
            this.object = object;
        }
    
        public static volatile int J = 100;
    
        @Override
        public void run() {
    
            for (int j = 0; j < 100; j++) {
                synchronized (object) {
                    if (flag > 1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        flag = 10;
                        object.notifyAll();
                    }
                }
                System.out.println("The value of J is: " + J);
                decJ();
                synchronized (object) {
                    if (flag>1) {
                        flag--;
                        try {
                            object.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    } else {
                        System.out.println("--------------------------");
                        flag = 10;
                        object.notifyAll();
                    }
                }
                if (j == 99) {
                    System.out.println("The value of J is: " + J);
                }
    
            }
    
        }
    }
    
    public static void main(String[] args) {
        Object object = new Object();
        ThreadSyncTen instance = new ThreadSyncTen();
        Thread thread1 = new Thread(instance.new ThreadA(object));
        Thread thread2 = new Thread(instance.new ThreadB(object));
        Thread thread3 = new Thread(instance.new ThreadC(object));
        Thread thread4 = new Thread(instance.new ThreadD(object));
        Thread thread5 = new Thread(instance.new ThreadE(object));
        Thread thread6 = new Thread(instance.new ThreadF(object));
        Thread thread7 = new Thread(instance.new ThreadG(object));
        Thread thread8 = new Thread(instance.new ThreadH(object));
        Thread thread9 = new Thread(instance.new ThreadI(object));
        Thread thread10 = new Thread(instance.new ThreadJ(object));
        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
        thread5.start();
        thread6.start();
        thread7.start();
        thread8.start();
        thread9.start();
        thread10.start();
    }
}
