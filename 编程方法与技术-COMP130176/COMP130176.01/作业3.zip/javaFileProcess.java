/*
 * @Author: Zheng
 * @Date: 2021-11-12 23:45:55
 * @LastEditors: Zheng
 * @LastEditTime: 2021-11-17 16:56:02
 * @Description: Homework three for java class. Find the "//todo:" comment line in all java files form the given file path. 
 */
import java.io.*;

public class javaFileProcess {

    /**
     * @description: traverse the given file path and find all the java file
     *               recursively, for every java file, call processJavaFile()
     * @param {String} path
     * @return {*}
     */
    public void findJavaFiles(File path) {
        for (File fileDir : path.listFiles()) {
            if (fileDir.isDirectory()) {
                findJavaFiles(fileDir);
            } else if (fileDir.isFile()) {
                if (fileDir.getName().endsWith(".java")) {
                    try {
                        processJavaFile(fileDir);
                    } catch (TodoNotFoundException e) {
                        System.out.println(e.getMessage());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    /**
     * @description: if find any "todo" comment in a file then return the path of
     *               the file, if no "todo" exists throw an user defined exception
     *               with message "todo not found"
     * @param {File} file
     * @return {*}
     * @throws IOException
     */
    public void processJavaFile(File file) throws TodoNotFoundException, IOException {
        BufferedReader bufReader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
        String input = null;
        boolean hasTodo = false;
        while ((input = bufReader.readLine()) != null) {
            if(input.indexOf("//todo:")!=-1){
                hasTodo = true;
                System.out.println(file.getAbsolutePath());
                bufReader.close();
                return;
            }
        }
        bufReader.close();
        if (!hasTodo) {
            throw new TodoNotFoundException("todo not found");
        }
    }

    class TodoNotFoundException extends Exception {
        public TodoNotFoundException(String msg) {
            super(msg);
        }
    }

    public static void main(String[] args) {
        // macOS file path
        File thisFilePath = new File("/Users/zhengyuanze/Desktop/作业3/test");
        javaFileProcess jfp = new javaFileProcess();
        jfp.findJavaFiles(thisFilePath);
    }
}
