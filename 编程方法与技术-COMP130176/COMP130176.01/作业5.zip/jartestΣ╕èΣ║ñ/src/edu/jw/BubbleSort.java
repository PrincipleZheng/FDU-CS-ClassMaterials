/*
 * @Author: Zheng
 * @Date: 2021-12-03 22:50:43
 * @LastEditors: Zheng
 * @LastEditTime: 2021-12-05 12:26:52
 * @Description: 请填写简介
 */
package edu.jw;

import edu.fudan.Sort;

public class BubbleSort implements Sort {
    public int[] sort(int[] input) {
        System.out.println("This is BubbleSort running...");
        System.out.println("Before Sorting：");
        for (int i = 0; i < input.length; i++) {
            System.out.print(String.valueOf(input[i] + " "));
        }
        System.out.println("");
        for (int i = input.length - 1; i > 0; i--) {
            for (int j = 0; j < i; j++) {
                if (input[j] > input[j + 1]) {
                    int temp = input[j];
                    input[j] = input[j + 1];
                    input[j + 1] = temp;
                }
            }
        }
        return input;
    }
}
