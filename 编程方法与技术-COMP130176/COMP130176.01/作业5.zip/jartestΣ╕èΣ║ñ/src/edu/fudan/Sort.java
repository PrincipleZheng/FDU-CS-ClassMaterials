/*
 * @Author: Zheng
 * @Date: 2021-12-03 22:50:58
 * @LastEditors: Zheng
 * @LastEditTime: 2021-12-05 12:27:33
 * @Description: Jar包练习作业的主类 包含public接口 Sort供给插件实现 以及Main类
 */
package edu.fudan;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * @description: public接口 Sort供给插件实现
 */
public interface Sort {
    public int[] sort(int[] input);
}

/**
 * @description: 主程序入口类
 */
class Main {
    public static void main(String[] args){

        FileReader fr;
        //default setting: edu.wjc.QuickSort
        String className = "QuickSort";
        String packageName = "edu.wjc.";
        try {
            String filePath = "./sort.conf";
            fr = new FileReader(filePath);
            Properties props = new Properties();
            props.load(fr);
            if (props.containsKey("classname")) {
                // System.out.println("name=" + props.get("classname"));
                className = (String) props.get("classname");
            }
            if (props.containsKey("packagename")) {
                packageName = (String) props.get("packagename");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            URL[] urls = new URL[] { new URL("file:" + className + ".jar") };
            URLClassLoader loader = new URLClassLoader(urls);
            Class<?> clazz = loader.loadClass(packageName + className);
            Sort test = (Sort) clazz.getDeclaredConstructor().newInstance();
            Class<?>[] parameterTypes = new Class[] { int[].class };
            Method m = clazz.getMethod("sort", parameterTypes);
            int[] array = new int[10];
            for (int i = 0; i < 10; i++) {
                array[i] = 10-i;
            }
            Object obj = m.invoke(test, (Object) array);
            array = (int[])obj;
            loader.close();
            System.out.println("After Sorting：");
            for(int i = 0; i < array.length; i++){
                System.out.print(String.valueOf(array[i]+" "));
            }
        } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
                | NoSuchMethodException | SecurityException | InstantiationException | IOException e) {
            e.printStackTrace();
        }
    }
}
