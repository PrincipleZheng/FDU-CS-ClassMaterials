# 作业5

郑源泽 19307130077

## 执行方法

进入当前根目录，执行命令`java -jar sort.jar`

## 调整配置文件

```properties
# 配置文件规则：
# 要包含完整的包名（packagename=edu.xxx） 
# classname即位排序算法的类名，由于一个插件代表一个排序算法，规定其与外层jar包同名（classname=XXXSort）

classname=BubbleSort
packagename=edu.jw.

# classname=QuickSort
# packagename=edu.wjc.
```

## 运行截图

![image-20211205124707147](/Users/zhengyuanze/Library/Application Support/typora-user-images/image-20211205124707147.png)

