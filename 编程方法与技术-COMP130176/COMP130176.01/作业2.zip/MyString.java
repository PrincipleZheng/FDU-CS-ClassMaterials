public class MyString {
    final char[] value;

    public MyString() {
        value = new char[0];
    }

    public MyString(char[] value) {
        this.value = value;
    }

    public int length() {
        return value.length;
    }

    public char[] getValue() {
        //返回一个新的数组
        char[] c = new char[this.value.length];
        System.arraycopy(this.value, 0, c, 0, this.value.length);
        return c;
    }

    public MyString concat(char[] v) {
        //字符串相连
        if (v.length == 0) return this;
        int aLength = this.length();
        int bLength = v.length;
        char[] newArray = new char[aLength + bLength];
        System.arraycopy(value, 0, newArray, 0, aLength);
        System.arraycopy(v, 0, newArray, aLength, bLength);
        return new MyString(newArray);

    }

    //KMP search Algorithm
    public int indexOf(char[] v) {
        //如果v是value 的子串，返回第一个元素的index。否则返回-1.
        if (this.length() == 0) {
            if (v.length == 0) {
                return 0;
            }
            return -1;
        }
        int i = 0;
        int j = 0;
        int myLen = this.length();
        int vLen = v.length;
        int[] next = new int[myLen];
        next = GetNextVal(this.value, next);
        while (i < myLen && j < vLen) {
            if (j == -1 || this.value[i] == v[j]) {
                i++;
                j++;
            } else {
                j = next[j];
            }
        }
        if (j == vLen)
            return i - j;
        else
            return -1;
    }

    // for the usage of KMP search Algorithm
    public int[] GetNextVal(char[] p, int[] next) {
        int pLen = p.length;
        next[0] = -1;
        int k = -1;
        int j = 0;
        while (j < pLen - 1) {
            if (k == -1 || p[j] == p[k]) {
                ++j;
                ++k;
                if (p[j] != p[k])
                    next[j] = k;
                else
                    next[j] = next[k];
            } else {
                k = next[k];
            }
        }
        return next;
    }

    public MyString replace(char[] v1, char[] v2) {
        //子串替换；如果v1是v2的子串 要避免重复替换
        int aLen = this.value.length;
        int Len1 = v1.length;
        int Len2 = v2.length;
        if (aLen == 0) {
            if (Len1 == 0) {
                return new MyString(v2);
            }
            return new MyString(this.value);
        }
        if (Len1 == 0) {
            if (Len2 == 0) {
                return new MyString();
            } else {
                char[] resVal = new char[(aLen + 1) * Len2 + aLen];
                int headNum = 0;
                for (char c : this.value) {

                    System.arraycopy(v2, 0, resVal, headNum, Len2);
                    headNum += Len2;
                    resVal[headNum] = c;
                    headNum++;
                }
                System.arraycopy(v2, 0, resVal, headNum, Len2);
                return new MyString(resVal);
            }
        }
        char[] blackBoard = new char[9999];
        //为了算法简单，牺牲一些内存，新建一个空数组，在tempStr上进行扫描
        int tempHeadFlag = 0;
        MyString tempStr = new MyString(this.value);
        while (tempStr.indexOf(v1) != -1) {
            //将已经识别的部分写入blackBoard
            int flagOfMatch = tempStr.indexOf(v1);
            for (int i = 0; i < flagOfMatch; i++) {
                blackBoard[tempHeadFlag] = tempStr.value[i];
                tempHeadFlag++;
            }
            for (char c : v2) {
                blackBoard[tempHeadFlag] = c;
                tempHeadFlag++;
            }
            //修改tempStr为先前的tempStr未进行识别的部分
            char[] newStrValue = new char[tempStr.length() - flagOfMatch - Len1];
            System.arraycopy(tempStr.value, flagOfMatch + Len1, newStrValue, 0, newStrValue.length);
            tempStr = new MyString(newStrValue);
        }
        //补上剩下的部分
        for (char c : tempStr.value) {
            blackBoard[tempHeadFlag] = c;
            tempHeadFlag++;
        }
        //将blackBoard上的串封装为MyString，并返回
        char[] res = new char[tempHeadFlag];
        System.arraycopy(blackBoard, 0, res, 0, res.length);
        return new MyString(res);

    }


}
