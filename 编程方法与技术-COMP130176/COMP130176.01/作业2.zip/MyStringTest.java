/**
 * MyStringTest
 * 效率测试参考了助教下发文件中的代码。
 */

public class MyStringTest {
//    正确性测试 注释掉了
//    private static void Test(MyString result, String expected) {
//        if (expected.equals(String.valueOf(result.getValue()))) {
//            return;
//        }
//        throw new Error("Wrong answer! It should be " + String.valueOf(expected) + ", but get "
//                + String.valueOf(result.getValue()));
//    }
//
//    private static void Test(int result, int expected) {
//        if (result == expected) {
//            return;
//        }
//        throw new Error(
//                "Wrong answer! It should be " + String.valueOf(expected) + ", but get " + String.valueOf(result));
//    }
//
//    private static void Test(char[] result, String expected) {
//        if (expected.equals(String.valueOf(result))) {
//            return;
//        }
//        throw new Error(
//                "Wrong answer! It should be " + String.valueOf(expected) + ", but get " + String.valueOf(result));
//    }
//
//    private static void TestMyString() {
//        char[] charArr = {'h', 'e', 'l', 'l', 'o'};
//        char[] emptyArr = {};
//        char[] subArr = {'e', 'l'};
//        char[] repeatArr = {'l'};
//        String hello = "hello";
//        MyString str = new MyString(charArr);
//        MyString emptyStr = new MyString(emptyArr);
//        Test(str.length(), 5);
//        Test(emptyStr.length(), 0);
//        Test(str.getValue(), hello);
//        Test(emptyStr.getValue(), "");
//        Test(emptyStr.indexOf(emptyArr), 0);
//        Test(emptyStr.indexOf(subArr), -1);
//        Test(str.indexOf(emptyArr), 0);
//        Test(str.indexOf(subArr), 1);
//        Test(str.indexOf(repeatArr), 2);
//        Test(str.concat(emptyArr), "hello");
//        Test(str.concat(subArr), "helloel");
//        Test(str.concat(repeatArr), "hellol");
//        Test(str.replace(subArr, charArr), "hhellolo");
//        Test(str.replace(repeatArr, charArr), "hehellohelloo");
//        Test(str.replace(emptyArr, charArr), "hello".replace("", "hello"));
//        Test(emptyStr.replace(emptyArr, charArr), "hello");
//        Test(emptyStr.replace(subArr, charArr), "");
//    }

    /**
     * 测试indexOf和replace的效率
     */
    private static void TestMyTestSpeed() {


        long TIMES6 = 1000000;
        int t = 5;
        long TestTimes = t*TIMES6;

        String stringOrig = "1234567812345678123456781234567812345678123456781234567812345679";
        char[] chars = stringOrig.toCharArray();
        String stringToBeFound = "123456789";
        char[] dest = stringToBeFound.toCharArray();

        String stringToBeReplaced = "1234567";
        char[] toBeReplaced = stringToBeReplaced.toCharArray();
        long startTime;
        long endTime;

        MyString a = new MyString(chars);
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            a.indexOf(dest); // System.out.println("ret = " + a.indexOf(dest));
        }
        endTime = System.currentTimeMillis();
        System.out.println("MyString.indexOf method: Time：" + (endTime - startTime) + "ms");
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            stringOrig.indexOf(stringToBeFound);
        }
        endTime = System.currentTimeMillis();
        System.out.println("String.indexOf method: Time：" + (endTime - startTime) + "ms");
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            a.replace(toBeReplaced, dest); // System.out.println("ret = " + a.indexOf(dest));
        }
        endTime = System.currentTimeMillis();
        System.out.println("MyString.replace method: Time：" + (endTime - startTime) + "ms");
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            stringOrig.replace(stringToBeReplaced, stringToBeFound);
        }
        endTime = System.currentTimeMillis();
        System.out.println("String.replace method: Time：" + (endTime - startTime) + "ms");
        stringToBeReplaced = "";
        toBeReplaced = stringToBeReplaced.toCharArray();
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            a.replace(toBeReplaced, dest); // System.out.println("ret = " + a.indexOf(dest));
        }
        endTime = System.currentTimeMillis();
        System.out.println("MyString.replace emptySubStr: Time：" + (endTime - startTime) + "ms");
        startTime = System.currentTimeMillis(); // 获取当前时间
        for (int i = 0; i < TestTimes; i++) {
            stringOrig.replace(stringToBeReplaced, stringToBeFound);
        }
        endTime = System.currentTimeMillis();
        System.out.println("String.replace emptySubStr: Time：" + (endTime - startTime) + "ms");
    }

    public static void main(String[] args) {
        TestMyTestSpeed();
    }
}
/*
*测试结果展示 标号代表（百万次）
* 1
MyString.indexOf method: Time：379ms
String.indexOf method: Time：20ms
MyString.replace method: Time：4670ms
String.replace method: Time：163ms
MyString.replace emptySubStr: Time：522ms
String.replace emptySubStr: Time：839ms
* 2
MyString.indexOf method: Time：672ms
String.indexOf method: Time：23ms
MyString.replace method: Time：8520ms
String.replace method: Time：287ms
MyString.replace emptySubStr: Time：1037ms
String.replace emptySubStr: Time：1634ms
* 3
MyString.indexOf method: Time：952ms
String.indexOf method: Time：19ms
MyString.replace method: Time：12165ms
String.replace method: Time：390ms
MyString.replace emptySubStr: Time：1448ms
String.replace emptySubStr: Time：2098ms
* 4
MyString.indexOf method: Time：1227ms
String.indexOf method: Time：19ms
MyString.replace method: Time：15906ms
String.replace method: Time：508ms
MyString.replace emptySubStr: Time：1802ms
String.replace emptySubStr: Time：3051ms
* 5
MyString.indexOf method: Time：1483ms
String.indexOf method: Time：18ms
MyString.replace method: Time：19265ms
String.replace method: Time：654ms
MyString.replace emptySubStr: Time：2330ms
String.replace emptySubStr: Time：3818ms
* */