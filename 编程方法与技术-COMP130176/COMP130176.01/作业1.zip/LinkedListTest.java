/**
 * @ClassName:     LinkListTest.java
 * @Description:   作业1-链表类的实现
 *
 * @author         郑源泽19307130077
 * @version        V1.0
 * @Date           10.10.2021
 */
/**
 * sanity check汇总：
 * 空链表的isExist、add、delete调用
 * delete方法调用后链表为空
 * 在LinkedList类中避免对于值为null的Element的方法调用
 * ......
 */
class Element {
    //内部数据保护
    private int n;
    private Element next;
    //通过方法访问被保护的数据
    public Element(){}
    public Element(int n, Element next){
        this.setNum(n);
        this.setNext(next);
    }
    public int getNum() {
        return this.n;
    }
    public Element getNext(){
        return this.next;
    }
    public void setNum(int num) {
        this.n = num;
    }
    public void setNext(Element e){
        this.next = e;
    }
}

class LinkedList {
    private Element first;

    public boolean isExist(Element e) {
        //应对空链表的情况
        if(first==null) return false;
        //应对链表中仅有一个元素，不进入循环的情况
        if(first.getNum()==e.getNum()) return true;
        for(Element temp = first; temp.getNext() != null; temp = temp.getNext()) {
            if (temp.getNum() == e.getNum())
                return true;
        }
        return false;
    }

    public boolean delete(Element e){
        //空链表直接返回false
        if(first==null){
            return false;
        }
        int flag = 0;
        while(first.getNum()==e.getNum()) {
            flag = 1;
            if(first.getNext()!=null) {
                first = first.getNext();
                //每次删除输出的辅助信息
                //System.out.println("delete one");
                //this.putOut();
            }
            else {
                first=null;
                //System.out.println("linklist is empty!");
                return true;
            }
        }
        Element temp = first;
        while(temp.getNext()!=null) {
            if(temp.getNext().getNum()==e.getNum()){
                if(temp.getNext().getNext()==null) temp.setNext(null);
                else temp.setNext(temp.getNext().getNext());
                //每次删除输出的辅助信息
                //System.out.println("delete one");
                //this.putOut();
                flag = 1;
                if(temp.getNext()!=null)
                    if(temp.getNext().getNum()!=e.getNum())
                        temp = temp.getNext();
            }
            else temp = temp.getNext();
        }
        return flag == 1;
    }

    public void add(Element e) {
        if (this.first == null){
            this.first = new Element(e.getNum(),null);
        }
        else {
            Element tempHead = first;
            while (tempHead.getNext() != null) {
                tempHead = tempHead.getNext();
            }
            //深拷贝e的数据到新插入的节点中
            Element e2 = new Element();
            e2.setNum(e.getNum());
            e2.setNext(null);
            tempHead.setNext(e2);
        }

    }

    //格式化输出链表的data值
    public void putOut(){
        if(first==null){
            System.out.println("empty linklist!");
        }
        else{
            Element tempHead = first;
            System.out.printf("%-4d",tempHead.getNum());
            while(tempHead.getNext()!=null){
                System.out.printf("%-4d",tempHead.getNext().getNum());
                tempHead=tempHead.getNext();
            }
            System.out.print("\n");
        }
    }

}

public class LinkedListTest{
    public static void main(String[] args) {
        Element node1 = new Element(1,null);
        Element node2 = new Element(2,null);
        Element node3 = new Element(3,null);
        Element node4 = new Element(4,null);


        LinkedList list = new LinkedList();
        System.out.println("空链表相关测试：");
        System.out.println("    调用delete结果：" + list.delete(node1));
        System.out.println("    调用isExist结果：" + list.isExist(node1));

        System.out.println("add功能测试：");
        list.add(node1);
        System.out.print('\t'+"加入node1   "); list.putOut();
        list.add(node2);
        System.out.print('\t'+"加入node2   "); list.putOut();
        list.add(node3);
        System.out.print('\t'+"加入node3   "); list.putOut();
        list.add(node2);
        System.out.print('\t'+"加入node2   "); list.putOut();
        list.add(node1);
        System.out.print('\t'+"加入node1   "); list.putOut();

        System.out.println("isExist功能测试：");
        System.out.println("    当前链表：");
        System.out.print('\t'); list.putOut();
        System.out.print("    isExist(node1)?");
        System.out.print('\t');System.out.println(list.isExist(node1));
        System.out.print("    isExist(node3)?");
        System.out.print('\t');System.out.println(list.isExist(node3));
        System.out.print("    isExist(node4)?");
        System.out.print('\t');System.out.println(list.isExist(node4));

        System.out.println("delete功能测试：");
        System.out.println("    当前链表：");
        System.out.print('\t'); list.putOut();
        System.out.print('\t'+"删除node1:  " + "返回值：" + list.delete(node1) + '\n');
        System.out.print("    当前链表：");
        System.out.print('\t'); list.putOut();
        System.out.print('\t'+"删除node4:  " + "返回值：" + list.delete(node4) + '\n');
        System.out.print("    当前链表：");
        System.out.print('\t'); list.putOut();
        System.out.print('\t'+"删除node2:  " + "返回值：" + list.delete(node2) + '\n');
        System.out.print("    当前链表：");
        System.out.print('\t'); list.putOut();
        System.out.print('\t'+"删除node3:  " + "返回值：" + list.delete(node3) + '\n');
        System.out.print("    当前链表：");
        System.out.print('\t'); list.putOut();
    }
}
